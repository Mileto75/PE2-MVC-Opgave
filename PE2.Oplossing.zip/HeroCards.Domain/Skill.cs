﻿namespace HeroCards.Domain
{
    public class Skill
    {
        public string Name { get; set; }
        public string Image { get; set; }
        public int StaminaCost { get; set; }
        public int MagicCost { get; set; }
    }
}
