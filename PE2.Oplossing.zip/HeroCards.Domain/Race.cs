﻿namespace HeroCards.Domain
{
    public enum Race
    {
        Dwarf,
        Elf,
        Halfling,
        Wizard,
        Human
    }
}
