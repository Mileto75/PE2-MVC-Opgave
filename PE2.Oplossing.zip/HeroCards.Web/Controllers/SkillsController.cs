﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HeroCards.Domain;
using HeroCards.Web.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace HeroCards.Web.Controllers
{
    public class SkillsController : Controller
    {
        HeroRepository heroRepository;
        SkillRepository skillRepository;
        RaceRepository raceRepository;

        public SkillsController()
        {
            heroRepository = new HeroRepository();
            skillRepository = new SkillRepository();
            raceRepository = new RaceRepository();
        }

        public IActionResult Index()
        {
            var vm = new SkillsIndexVm
            {
                Skills = skillRepository.GetSkills()
            };
            return View(vm);
        }

        [Route("Skills/{skillName}")]
        public IActionResult Display([FromRoute] string skillName)
        {
            ViewData["NavItem"] = "Skills";

            var skill = skillRepository.GetSkillByName(skillName);
            if (skill == null)
                return NotFound();

            var vm = new SkillsDisplayVm
            {
                Skill = skill,
                HeroesWithSkill = heroRepository.GetHeroesWithSkill(skillName),
                RacesWithSkill = raceRepository.GetRacesWithSkill(skillName)
            };

            return View(vm);
        }
    }
}