﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using HeroCards.Domain;
using HeroCards.Web.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace HeroCards.Web.Controllers
{
    public class HomeController : Controller
    {
        HeroRepository heroRepository;
        SkillRepository skillRepository;
        RaceRepository raceRepository;

        public HomeController()
        {
            heroRepository = new HeroRepository();
            skillRepository = new SkillRepository();
            raceRepository = new RaceRepository();
        }

        public IActionResult Index()
        {
            var vm = new HomeIndexVm
            {
                Heroes = heroRepository.GetHeroes().OrderBy(h => h.Name),
                Skills = skillRepository.GetSkills().OrderBy(h => h.Name),
                Races = raceRepository.GetRaces().OrderBy(r => r.ToString())
            };
            return View(vm);
        }

        [Route("Heroes/Search/Skill/{skillName}")]
        public IActionResult SearchBySkill(string skillName)
        {
            var vm = new HomeSearchVm
            {
                FoundHeroes = heroRepository.GetHeroesWithSkill(skillName),
                SearchDescription = $"You searched for heroes with skill \"{skillName}\""
            };
            return View("Search", vm);
        }

        [Route("Heroes/Search/{propertyName}/{propertyValue}")]
        public IActionResult SearchByProperty(string propertyName, int propertyValue)
        {
            var vm = new HomeSearchVm();
            switch (propertyName)
            {
                case nameof(Hero.Health):
                    vm.FoundHeroes = heroRepository.GetHeroesWithHealth(propertyValue);
                    break;
                case nameof(Hero.Magic):
                    vm.FoundHeroes = heroRepository.GetHeroesWithMagic(propertyValue);
                    break;
                case nameof(Hero.Stamina):
                    vm.FoundHeroes = heroRepository.GetHeroesWithStamina(propertyValue);
                    break;
                default:
                    return NotFound();
            }
            vm.SearchDescription = $"You searched for heroes with {propertyName} >= {propertyValue}";
            return View("Search", vm);
        }
    }
}
