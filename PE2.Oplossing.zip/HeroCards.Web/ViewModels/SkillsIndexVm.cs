﻿using HeroCards.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HeroCards.Web.ViewModels
{
    public class SkillsIndexVm
    {
        public IEnumerable<Skill> Skills { get; set; }
    }
}
