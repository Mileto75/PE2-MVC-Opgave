﻿using HeroCards.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HeroCards.Web.ViewModels
{
    public class HomeIndexVm
    {
        public IEnumerable<Hero> Heroes { get; set; }
        public IEnumerable<Skill> Skills { get; set; }
        public IEnumerable<Race> Races { get; set; }
    }
}
