﻿using HeroCards.Domain;
using System.Collections.Generic;

namespace HeroCards.Web.ViewModels
{
    public class HomeSearchVm
    {
        public IEnumerable<Hero> FoundHeroes { get; set; }
        public string SearchDescription { get; set; }
    }
}
